"""Row 21 probes: tutorials/detr_detection_colab.ipynb at the reviewed commit.

CPU only, install skipped via the notebook's DIMER_NOTEBOOK_CI_PREINSTALLED hook, pinned build venv,
weights hard-linked from a local snapshot and re-hashed by the notebook's own verify_snapshot (the
manifest is written fresh by cell 9, never linked).
Usage: python run_probes.py <worktree> <weights_src> <workdir>
"""
import contextlib
import io
import json
import os
import platform
import re
import sys
import time
import traceback
from pathlib import Path

WT, WSRC, WORK = (Path(a) for a in sys.argv[1:4])
NB = WT / "tutorials" / "detr_detection_colab.ipynb"
RESULTS = {"env": {}, "static": {}, "cells": [], "probes": {}}
OUT = Path(__file__).with_name("results.json")


def save():
    OUT.write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]


def src(i):
    return "".join(cells[i]["source"])


code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]

# ---- static
st = RESULTS["static"]
st["nbformat"] = [nb.get("nbformat"), nb.get("nbformat_minor")]
st["n_cells"], st["n_code"] = len(cells), len(code_idx)
st["metadata_dimer"] = nb["metadata"].get("dimer")
st["outputs_present"] = sum(len(c.get("outputs", [])) for c in cells if c["cell_type"] == "code")
compile_err = {}
for i in code_idx:
    try:
        compile(src(i), f"cell{i}", "exec")
    except SyntaxError as e:
        compile_err[i] = str(e)
st["compile_errors"] = compile_err
alltext = "\n".join(src(i) for i in range(len(cells)))
st["todo_markers"] = re.findall(r"\b(TODO|TBD|FIXME|WRITE ME)\b", alltext)
st["filterwarnings"] = len(re.findall(r"filterwarnings", alltext))
st["pip_install_in_kernel"] = "'pip', 'install'" in src(3)
st["uses_uv"] = bool(re.search(r"\buv (venv|pip)\b", alltext))
st["restart_instruction_in_cell3"] = "Restart the runtime" in src(3)
st["cellView_form_cells"] = [i for i in code_idx if cells[i]["metadata"].get("cellView") == "form"]
st["infrastructure_labelled"] = [i for i in range(len(cells)) if "Infrastructure" in src(i)]
md = "\n".join(src(i) for i in range(len(cells)) if cells[i]["cell_type"] == "markdown")
st["guided_markers"] = {k: (k.lower() in md.lower()) for k in [
    "How to use this notebook", "Roadmap", "Glossary", "Predict", "Check your reasoning", "What to notice",
    "What to look for", "Expected result", "Troubleshooting", "conclusion", "audience", "Infrastructure"]}
st["look_for_count"] = len(re.findall(r"(?i)look for", md))
st["section10_claim"] = [ln for ln in src(22).splitlines() if "detects the new sign" in ln]
st["runtimes_not_measured_claim"] = "Runtimes are not measured in this revision" in src(1)
st["byod_min_records_claim"] = "at least 2 records" in src(28)
for cell_i, rel in ((5, "src/detr_detection_pipeline/pipeline.py"),
                    (7, "src/detr_detection_pipeline/samples.py")):
    mod = (WT / rel).read_text(encoding="utf-8").splitlines()
    cell = src(cell_i).splitlines()
    st[f"carried_cell_{cell_i}"] = {"module_lines": len(mod), "cell_lines": len(cell),
                                    "differing_lines": sum(1 for a, b in zip(mod, cell) if a != b)}
save()

# ---- workspace
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
wdir = WORK / "weights" / "detr-resnet-50"
wdir.mkdir(parents=True, exist_ok=True)
for name in ("README.md", "config.json", "model.safetensors", "preprocessor_config.json"):
    target = wdir / name
    if not target.exists():
        os.link(WSRC / name, target)
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

ns = {"__name__": "__main__"}


def run_cell(i, source=None, label=None):
    buf = io.StringIO()
    t0 = time.time()
    rec = {"cell": i, "label": label or f"cell {i}"}
    try:
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            exec(compile(source if source is not None else src(i), f"cell{i}", "exec"), ns)
        rec["status"] = "ok"
    except Exception as exc:  # noqa: BLE001
        rec["status"] = "error"
        rec["error"] = f"{type(exc).__name__}: {exc}"
    rec["seconds"] = round(time.time() - t0, 1)
    rec["stdout"] = buf.getvalue()[-3000:]
    RESULTS["cells"].append(rec)
    save()
    print(rec["label"], rec["status"], rec["seconds"], flush=True)
    return rec


# ---- P1 default path, every code cell in order, defaults unchanged
for i in code_idx:
    r = run_cell(i, label=f"P1 cell {i}")
    if r["status"] != "ok":
        break
P = RESULTS["probes"]
import torch  # noqa: E402

RESULTS["env"] = {"python": platform.python_version(), "torch": torch.__version__, "cuda": torch.cuda.is_available(),
                  "threads": torch.get_num_threads(), "executable": sys.executable, "platform": platform.platform()}
save()

# ---- P2 adapted score distribution at the operating threshold
try:
    adapter, new_records, held_out = ns["adapter"], ns["new_records"], ns["held_out"]
    rows = []
    for rec in new_records:
        dets = adapter.detect(rec["image"], threshold=0.0)["detections"]
        rows.append({"id": rec["id"], "truth": rec["labels"],
                     "max_score": round(max((d["score"] for d in dets), default=0.0), 4),
                     **{f"n_at_{t}": sum(d["score"] >= t for d in dets) for t in (0.9, 0.7, 0.5, 0.3, 0.1)}})
    held = []
    for rec in held_out:
        dets = adapter.detect(rec["image"], threshold=0.0)["detections"]
        held.append(round(max((d["score"] for d in dets), default=0.0), 4))
    ev07 = adapter.evaluate(held_out, threshold=0.9)
    ev03 = adapter.evaluate(held_out, threshold=0.3)
    P["P2_operating_threshold"] = {
        "new_data": rows, "held_out_max_score_per_image": held,
        "held_out_ap50_at_0.9": ev07["ap50"], "held_out_ap_at_0.9": ev07["ap"],
        "held_out_ap50_at_0.3": ev03["ap50"],
        "default_eval": {k: ns["adapted"][k] for k in ("ap", "ap50", "ap75", "threshold")}}
    P["P2_csv_rows"] = (WORK / "outputs" / "detr_detection_detections.csv").read_text(
        encoding="utf-8").splitlines()
except Exception:  # noqa: BLE001
    P["P2_operating_threshold"] = {"error": traceback.format_exc()[-1500:]}
save()

# ---- P3 Try-next: change FREEZE_BACKBONE in cell 19 and re-run that cell (EPOCHS lowered to 2 for time)
try:
    first_run_losses = ns["run"]["epoch_losses"]
    ns["EPOCHS"] = 2
    s19 = src(19).replace("FREEZE_BACKBONE = True", "FREEZE_BACKBONE = False")
    r = run_cell(19, s19, "P3 rerun cell 19 with FREEZE_BACKBONE=False (EPOCHS=2)")
    r21 = run_cell(21, None, "P3 rerun cell 21")
    P["P3_rerun_continues_training"] = {
        "default_run_epoch_losses": first_run_losses,
        "rerun_epoch_losses": ns["run"]["epoch_losses"],
        "rerun_freeze_backbone": ns["run"]["freeze_backbone"],
        "adapted_after_rerun": {k: ns["adapted"][k] for k in ("ap", "ap50")},
        "baseline_unchanged": {k: ns["baseline"][k] for k in ("ap", "ap50")},
        "cell19_status": r["status"], "cell21_stdout": r21["stdout"]}
except Exception:  # noqa: BLE001
    P["P3_rerun_continues_training"] = {"error": traceback.format_exc()[-1500:]}
save()

# ---- BYOD
from PIL import Image  # noqa: E402

sign_dataset = ns["sign_dataset"]


def write_ds(path, records, mutate=None):
    path.mkdir(parents=True, exist_ok=True)
    entries = []
    for k, r in enumerate(records):
        fn = f"img{k:03d}.png"
        r["image"].save(path / fn)
        entries.append({"file": fn, "boxes": r["boxes"], "labels": r["labels"]})
    if mutate:
        entries = mutate(entries)
    if entries is not None:
        (path / "annotations.json").write_text(json.dumps(entries), encoding="utf-8")
    return path


def byod_cell(dataset_dir=None, image_path=None, class_names=""):
    s = src(29)
    if dataset_dir is not None:
        s = s.replace("USE_BYOD_DATASET = False", "USE_BYOD_DATASET = True")
        s = s.replace('BYOD_DATASET_DIR = ""', f"BYOD_DATASET_DIR = {str(dataset_dir)!r}")
    if image_path is not None:
        s = s.replace("USE_BYOD_IMAGE = False", "USE_BYOD_IMAGE = True")
        s = s.replace('BYOD_IMAGE_PATH = ""', f"BYOD_IMAGE_PATH = {str(image_path)!r}")
    if class_names:
        s = s.replace('BYOD_CLASS_NAMES = ""', f"BYOD_CLASS_NAMES = {class_names!r}")
    return s


B = WORK / "byod_probe"
B.mkdir(parents=True, exist_ok=True)
ns["EPOCHS"] = 2
try:
    d = write_ds(B / "pos", sign_dataset(10, seed=7))
    Image.new("RGB", (640, 640), (120, 120, 120)).save(d / "neg.png")
    ann = json.loads((d / "annotations.json").read_text(encoding="utf-8"))
    ann.append({"file": "neg.png", "boxes": [], "labels": []})
    (d / "annotations.json").write_text(json.dumps(ann), encoding="utf-8")
    before = sorted(p.name for p in (WORK / "outputs").iterdir())
    r = run_cell(29, byod_cell(dataset_dir=d), "P4 BYOD dataset positive (11 records incl. 1 no-box, EPOCHS=2)")
    after = sorted(p.name for p in (WORK / "outputs").iterdir())
    P["P4_byod_positive"] = {
        "status": r["status"], "error": r.get("error"), "seconds": r["seconds"], "stdout": r["stdout"],
        "new_outputs": sorted(set(after) - set(before)),
        "result_json_mentions_byod": "byod" in (WORK / "outputs" / "detr_detection_result.json").read_text(
            encoding="utf-8").lower()}
except Exception:  # noqa: BLE001
    P["P4_byod_positive"] = {"error": traceback.format_exc()[-1500:]}
save()

neg_cases = {
    "no_annotations_json": lambda p: write_ds(p, sign_dataset(3, seed=8), mutate=lambda e: None),
    "entry_missing_labels": lambda p: write_ds(
        p, sign_dataset(3, seed=8), mutate=lambda e: [{k: v for k, v in x.items() if k != "labels"} for x in e]),
    "unknown_label_vs_class_names": lambda p: write_ds(p, sign_dataset(3, seed=8)),
    "missing_image_file": lambda p: write_ds(
        p, sign_dataset(3, seed=8), mutate=lambda e: e + [{"file": "absent.png", "boxes": [], "labels": []}]),
    "xywh_boxes_out_of_bounds": lambda p: write_ds(
        p, sign_dataset(3, seed=8),
        mutate=lambda e: [{**x, "boxes": [[b[0], b[1], b[2] - b[0] + 600, b[3] - b[1]] for b in x["boxes"]]}
                          for x in e]),
    "parent_traversal": lambda p: write_ds(
        p, sign_dataset(3, seed=8), mutate=lambda e: e + [{"file": "../neg.png", "boxes": [], "labels": []}]),
    "one_record": lambda p: write_ds(p, sign_dataset(1, seed=8)),
    "coco_format_dict": lambda p: write_ds(
        p, sign_dataset(2, seed=8), mutate=lambda e: {"images": [], "annotations": [], "categories": []}),
}
P["P5_byod_negatives"] = {}
for name, make in neg_cases.items():
    d = make(B / name)
    cn = "stop-sign,yield-sign" if name == "unknown_label_vs_class_names" else ""
    r = run_cell(29, byod_cell(dataset_dir=d, class_names=cn), f"P5 {name}")
    P["P5_byod_negatives"][name] = {"status": r["status"], "error": r.get("error"), "seconds": r["seconds"]}
    save()

img_cases = {}
p_ok = B / "photo.png"
ns["tutorial_scene"]()[0].save(p_ok)
p_tiny = B / "tiny.png"
Image.new("RGB", (8, 8)).save(p_tiny)
p_txt = B / "notimage.png"
p_txt.write_text("hello", encoding="utf-8")
for name, p in (("valid_scene", p_ok), ("tiny_8px", p_tiny), ("text_as_png", p_txt), ("missing_path", B / "nope.jpg")):
    r = run_cell(29, byod_cell(image_path=p), f"P6 BYOD image {name}")
    img_cases[name] = {"status": r["status"], "error": r.get("error"), "stdout": r["stdout"][-700:]}
P["P6_byod_image"] = img_cases
save()
print("done", flush=True)
